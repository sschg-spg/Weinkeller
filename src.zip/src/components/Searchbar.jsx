import "./SearchBar.css";

function SearchBar() {
  return (
    <div className="search-bar">
      <input
        type="text"
        placeholder="🔍 Suche nach Name, Rebsorte oder Herkunft..."
      />
    </div>
  );
}

export default SearchBar;