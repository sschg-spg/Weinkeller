function WineForm({
  show,
  onClose,
  onSave,
  newWine,
  setNewWine,
}) {
  if (!show) return null;

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Neuen Wein hinzufügen</h2>

        <input
          placeholder="Name"
          value={newWine.name}
          onChange={(e) =>
            setNewWine({ ...newWine, name: e.target.value })
          }
        />

        <input
          placeholder="Jahrgang"
          value={newWine.year}
          onChange={(e) =>
            setNewWine({ ...newWine, year: e.target.value })
          }
        />

        <input
          placeholder="Rebsorte"
          value={newWine.grape}
          onChange={(e) =>
            setNewWine({ ...newWine, grape: e.target.value })
          }
        />

        <input
          placeholder="Herkunft"
          value={newWine.country}
          onChange={(e) =>
            setNewWine({ ...newWine, country: e.target.value })
          }
        />

        <input
          placeholder="Lagerort"
          value={newWine.location}
          onChange={(e) =>
            setNewWine({ ...newWine, location: e.target.value })
          }
        />

        <div className="modal-buttons">
          <button className="cancel" onClick={onClose}>
            Abbrechen
          </button>

          <button className="save" onClick={onSave}>
            Speichern
          </button>
        </div>
      </div>
    </div>
  );
}

export default WineForm;