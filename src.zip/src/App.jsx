import WineForm from "./components/WineForm";
import { useState } from "react";

import Header from "./components/Header";
import SearchBar from "./components/SearchBar";
import WineTable from "./components/WineTable";

import "./App.css";

function App() {
const [editIndex, setEditIndex] = useState(null);

  const [wines, setWines] = useState([
    {
      name: "Grüner Veltliner",
      year: "2022",
      grape: "Grüner Veltliner",
      country: "Österreich",
      location: "Regal A1",
    },
    {
      name: "Chianti Classico",
      year: "2019",
      grape: "Sangiovese",
      country: "Italien",
      location: "Regal B2",
    },
  ]);

  const [newWine, setNewWine] = useState({
    name: "",
    year: "",
    grape: "",
    country: "",
    location: "",
  });

  function addWine() {
    if (
      !newWine.name ||
      !newWine.year ||
      !newWine.grape ||
      !newWine.country ||
      !newWine.location
    ) {
      alert("Bitte alle Felder ausfüllen.");
      return;
    }

    if (editIndex === null) {
  setWines([...wines, newWine]);
} else {
  const updatedWines = [...wines];
  updatedWines[editIndex] = newWine;
  setWines(updatedWines);
  setEditIndex(null);
}

    setNewWine({
      name: "",
      year: "",
      grape: "",
      country: "",
      location: "",
    });

    setShowForm(false);
  }

  return (
    <div className="app">
      <Header onAdd={() => setShowForm(true)} />

      <SearchBar />

<WineTable
  wines={wines}
  onDelete={(index) => {
    setWines(wines.filter((_, i) => i !== index));
  }}
  onEdit={(index) => {
    setNewWine(wines[index]);
    setEditIndex(index);
    setShowForm(true);
  }}
/>
      {showForm && (
        <div className="modal">
          <div className="modal-content">
            <h2>Neuen Wein hinzufügen</h2>

            <input
              placeholder="Name"
              value={newWine.name}
              onChange={(e) =>
                setNewWine({ ...newWine, name: e.target.value })
              }
            />

            <input
              placeholder="Jahrgang"
              value={newWine.year}
              onChange={(e) =>
                setNewWine({ ...newWine, year: e.target.value })
              }
            />

            <input
              placeholder="Rebsorte"
              value={newWine.grape}
              onChange={(e) =>
                setNewWine({ ...newWine, grape: e.target.value })
              }
            />

            <input
              placeholder="Herkunft"
              value={newWine.country}
              onChange={(e) =>
                setNewWine({ ...newWine, country: e.target.value })
              }
            />

            <input
              placeholder="Lagerort"
              value={newWine.location}
              onChange={(e) =>
                setNewWine({ ...newWine, location: e.target.value })
              }
            />

            <div className="modal-buttons">
              <button
                className="cancel"
                onClick={() => setShowForm(false)}
              >
                Abbrechen
              </button>

              <button
                className="save"
                onClick={addWine}
              >
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;